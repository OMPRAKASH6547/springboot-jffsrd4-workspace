package com.jsp.springbootsimpleprojectcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSimpleProjectCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
