package com.jsp.springbootcrudoprationwithjunit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudOprationwithJunitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudOprationwithJunitApplication.class, args);
	}

}
